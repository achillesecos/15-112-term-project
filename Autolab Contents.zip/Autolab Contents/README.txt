{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf100
{\fonttbl\f0\fswiss\fcharset0 Helvetica-Bold;\f1\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\b\fs24 \cf0 Carnegie Mellon Map README
\f1\b0 \
\

\f0\b Description
\f1\b0 \
This project is a map application specifically restricted to Carnegie Mellon\'92s main campus. This application can be used by any member of the Pittsburgh or Carnegie Mellon community to optimally route directions from location to location in campus. A special feature added for students is the ability to import one\'92s schedule (.ics file) and be able to route paths from class to class based on the classes for the current day. The user will also see the distance in miles from the path of two locations.\
\

\f0\b How to run project
\f1\b0 \
Simply just download the folder and run it. No module manager is used\
\

\f0\b Installing Libraries
\f1\b0 \
Only library used is PIL, for installing the image of the map on the canvas. It is already imported in the map.py file. To install the module, run \'91pip install PIL\'92 on terminal.\
\

\f0\b Shortcut Commands\

\f1\b0 None}